Component({
  options: {
    multipleSlots: true
  },

  properties: {
    btn_ok: {
      type: String,
      value: '确定'
    },
    phone: {
      type: String,
      value: '电话'
    },
    photo: {
      type: String,
      value: '二维码'
    },
  },
  data: {
    flag: true,
  },
  methods: {
    hideInfo: function () {
      this.setData({
        flag: !this.data.flag
      })
    },
    showInfo() {
      this.setData({
        flag: !this.data.flag
      })
    },
    success() {
      this.triggerEvent("success");
    },
    call(){
      this.triggerEvent("call");
    }
  }
})