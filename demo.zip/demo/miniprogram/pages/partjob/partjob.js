// pages/partjob/partjob.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    users:{},
    userid:''
  },
  pub:function()
  {
    var that = this;
    wx.navigateTo({
      url: '/pages/publish/publish?userid='+that.data.userid,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.setData({
      userid:e.userid
    });
    this.getuser();
  },
  getuser(){
    let that=this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form5.action',
      method:'GET',
      header: {
        'content-type': 'application/json'
      },
      success(res){
        that.setData({ users: res.data});
        console.log(res);
      }
    })
  },
  info:function(e){
    var that=this;
    var data1 = e.currentTarget.dataset;
    console.log(data1);
    var job1 = data1.index.job;
    var startdata1 = data1.index.startdata;
    var enddata1 = data1.index.enddata;
    var name1 = data1.index.name;
    var selery1 = data1.index.selery;
    var addr1 = data1.index.addr;
    var test1 = data1.index.test;
    var phone1 = data1.index.phone;
    var clubid=data1.index.id;
    wx.navigateTo({
      url: '/pages/partjobInfo/partjobInfo?job1=' + job1 + "&name1=" + name1 + "&startdata1=" + startdata1 + "&enddata1=" + enddata1 + "&selery1=" + selery1 + "&addr1=" + addr1 + "&test1=" + test1 + "&phone1=" + phone1 + "&userid=" + that.data.userid + "&clubid=" + clubid,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})