const app = getApp();
Page({
  data: {
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  onLoad: function () {
    var that = this;
    // // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        if (res.code) {
          //发起网络请求
          wx.request({
            url: 'http://localhost:8082/SHdemo/form1.action',
            data: {
              code: res.code
            },
            success: res => {
              console.log(res);
            }
            })
  } else {
    console.log('登录失败！' + res.errMsg)
  }
}
      })
  },
  bindGetUserInfo: function (e) {
    if (e.detail.userInfo) {
      //用户按了允许授权按钮
      //输出用户信息
      console.log(e.detail.userInfo)
      var that = this;
      //插入登录的用户的相关信息到数据库
      wx.request({
        url: 'http://localhost:8082/SHdemo/form2.action',
         data: {

           nickName: e.detail.userInfo.nickName,
           avatarUrl: e.detail.userInfo.avatarUrl,
           province: e.detail.userInfo.province,
           city: e.detail.userInfo.city,
           gender: e.detail.userInfo.gender,
           country: e.detail.userInfo.country,
           phone: e.detail.userInfo.phone,
           Headurl:e.detail.userInfo.Headurl,
           codeurl:e.detail.userInfo.codeurl
         },
         header: {
           'content-type': 'application/json'
         },
         success: function (res) {
           //从数据库获取用户信息
           console.log("插入小程序登录用户信息成功！");
           wx.switchTab({
             url: '/pages/loadsuccess/loadsuccess',
           })
         }
       });
      //授权成功后，跳转进入小程序首页
      console.log("授权成功")
      
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
        showCancel: false,
        confirmText: '返回授权',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击了“返回授权”')
          }
        }
      })
    }
  },
  //获取用户信息接口


})
