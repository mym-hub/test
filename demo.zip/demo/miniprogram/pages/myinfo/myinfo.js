// pages/myinfo/myinfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tip:'',
    name:'',
    phone:'',
    sushe:'',
    xueyuan:'',
    imgpath:'../../images/相机.png',
    photo:'',
    uid:'',
    info:{}
   },
  formsubmit:function(e){
    if (e.detail.value.name.length == 0 || e.detail.value.phone.length == 0 || e.detail.value.sushe.length == 0 || e.detail.value.xueyuan.length == 0 ){
    this.setData({
      tip:'填写信息不能为空',
      name: '',
      phone: '',
      sushe: '',
      xueyuan: '',
    })
    return;
  };
  this.setData({ tip: '' }),
  wx.request({
    url: 'http://localhost:8082/SHdemo/form4.action',
    data:{
      userid:this.data.uid,
      name:e.detail.value.name,
      phone: e.detail.value.phone,
      sushe: e.detail.value.sushe,
      xueyuan: e.detail.value.xueyuan,
      photo:e.detail.value.photo
    },
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
      wx.showToast({
        title: '成功',
        icon: 'success',
        duration:2000,
      });
      wx.navigateBack({
        delta: 1
      })
      console.log(e.detail.value+"成功！")
    }
  })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var userid=e.userid;
    this.setData({
      uid: userid
    });
    this.getinfo(userid);
  },
  getinfo(userid)
  {
    var that=this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form8.action',
      data:{userid:that.data.uid},
      header: {
        'content-type': 'application/json'
      },
      success(res){
        that.setData({
          info:res.data.info
        });
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  uploadPhoto(e){
    let that=this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        let tempFilePaths = res.tempFilePaths;
        wx.uploadFile({
          url: 'http://localhost:8082/SHdemo/Uploadphoto',
          filePath: tempFilePaths[0],
          name:'file',
          header: {
            "Content-Type": "multipart/form-data"
          },
          success(res) {
            if (res.statusCode != 200) {
              wx.showModal({ title: '提示', content: '上传失败', showCancel: false });
              return;
            } else {
              that.setData({ imgpath: tempFilePaths[0]}),
              console.log(tempFilePaths[0]),
              wx.showModal({
                title: '提示',
                content: '上传成功',
                showCancel:false,
                success: function(res){
                  if(res.confirm)
                  {console.log("成功")};
                  var photo1 = tempFilePaths[0].split('/');
                  var a=photo1[photo1.length-1];
                  console.log(tempFilePaths);
                  console.log(a.length);
                  that.setData({ photo:a})
                }
              })
              console.log(res);
            }
          },
          fail(e) {
            wx.showModal({ title: '提示', content: '上传失败', showCancel: false });
          },
          complete() {
            wx.hideToast(); //隐藏Toast
          }
        })
      }
    })
  },
})