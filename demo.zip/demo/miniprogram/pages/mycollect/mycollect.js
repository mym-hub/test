// pages/mypublic/mypublic.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tab: 0,
    currentTab: 0,
    job: '',
    partjob: {},
    len1: 0,
    club: {},
    club_len: 0
  },
  switchnav: function (e) {
    console.log(e);
    var that = this;
    var id = e.target.id;
    if (this.data.currentTab == id) { return false; }
    else { that.setData({ currentTab: id }) }
    that.setData({ tab: id });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getptinfo();
    this.getclubinfo();
  },
  getclubinfo() {
    let that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form14.action',
      data: { userid: 1 },
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        that.setData({ club: res.data.list });
        that.setData({ club_len: res.data.len });
        console.log(res.data);
      }
    })
  },
  getptinfo() {
    let that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form13.action',
      data: { userid: 1 },
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        that.setData({ partjob: res.data.list });
        that.setData({ len: res.data.len });
        console.log(res.data);
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})