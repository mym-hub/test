// pages/partjob/partjob.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    clubs: {},
    userid:''
  },
  pub: function () {
    var that=this;
    wx.navigateTo({
      url: '/pages/clubInfo/clubInfo?userid='+that.data.userid,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.getclub();
    this.setData({
      userid:e.userid
    })
  },
  getclub() {
    let that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form10.action',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        that.setData({ clubs: res.data});
        console.log(res);
      }
    })
  },
  info: function (e) {
    var that=this;
    var data1 = e.currentTarget.dataset;
    console.log(data1);
    var cname1 = data1.index.cname;
    var minister1 = data1.index.minister;
    var enddata1 = data1.index.enddata;
    var pubtime = data1.index.pubdata;
    var date = new Date(data1.index.pubdata.time);
    var Y = date.getFullYear();
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var now = Y + "-" + M + "-" + D + " " + pubtime.hours + ":" + pubtime.minutes + ":" + pubtime.seconds;
    var test1 = data1.index.test;
    var depart1=data1.index.depart;
    var userid1 = that.data.userid;
    wx.navigateTo({
      url: '/pages/clubdate/clubdate?cname1=' + cname1 + "&minister1=" + minister1 + "&enddata1=" + enddata1 + "&pubdata1=" + now + "&test1=" + test1 + "&depart1=" + depart1 + "&userid1=" + userid1,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})