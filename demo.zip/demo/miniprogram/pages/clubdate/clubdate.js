// pages/clubdate/clubdate.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cname:'',
    minister:'',
    depart:'',
    enddata:'',
    pubdata:'',
    userid:'',
    test:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.setData({
      cname: e.cname1,
      minister:e.minister1,
      depart: e.depart1,
      enddata: e.enddata1,
      pubdata: e.pubdata1,
      userid: e.userid1,
      test: e.test1,
      clubid: '',
      photo: '../../images/二维码.jpg',
      scicon: '../../images/收藏.png'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  shoucang: function () {
    var that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form11.action',
      header: {
        'content-type': 'application/json'
      },
      data: {
        userid: that.data.userid,
        clubid: that.data.clubid
      },
      success: function (res) {
        wx.showToast({
          title: '已收藏',
          icon: 'success',
          duration: 1500
        })
      }
    });
  },
  lianxi: function () {
    var that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form8.action',
      data: { userid: that.data.userid },
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        that.setData({
          info: res.data.info
        });
        console.log(res);
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.popup = this.selectComponent("#popup");
    this.info = this.selectComponent("#info");
  },
  showPopup() {
    this.popup.showPopup();
  },

  //取消事件
  _error() {
    console.log('你点击了取消');
    this.popup.hidePopup();
  },
  //确认事件
  _success() {
    console.log('你点击了确定');
    this.popup.hidePopup();
  },

  showInfo() {
    this.info.showInfo();
  },
  success() {
    console.log('你点击了确定');
    this.info.hideInfo();
  },
  call() {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.phone,
    }
    );
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})