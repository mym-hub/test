// pages/publish/publish.js
var timestamp = Date.parse(new Date());
var date = new Date(timestamp);
var Y = date.getFullYear();
var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
var now=Y+"-"+M+"-"+D;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userid:'',
    date:now,
    date1:now,
    name1:'',
    startdata:'',
    job:'',
    enddata:'',
    addr:'',
    phone:'',
    selery:'',
    testarea:'',
    tip:''
  },
  bindchagedata: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindchagedata1: function (e) {
    this.setData({
      date1: e.detail.value
    })
  },
  bindsubmit:function(e)
  {
    if (e.detail.value.name1.length == 0 || e.detail.value.addr.length == 0 || e.detail.value.phone.length == 0 || e.detail.value.selery.length == 0 || e.detail.value.testarea.length == 0 || e.detail.value.job.length == 0)
  {
    this.setData({
      tip: '请完整填写信息'
    });
    return;
  };
  this.setData({tip:''});
    wx.request({
      url: 'http://localhost:8082/SHdemo/form3.action',
      data: {
        name1: e.detail.value.name1,
        startdata: e.detail.value.startdata,
        enddata: e.detail.value.enddata,
        addr: e.detail.value.addr,
        phone: e.detail.value.phone,
        selery: e.detail.value.selery,
        testarea: e.detail.value.testarea,
        job:e.detail.value.job,
        addtime:now,
        state:0,
        userid:this.data.userid,
        isdelete:0
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        wx.showToast({
          title: '成功',
          icon: 'success',
          duration:2000,
        });
        setTimeout(function(){
          wx.navigateBack({
            delta: 1
          })
        },1000)
        
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.setData({
      userid:e.userid
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})