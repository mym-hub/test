// pages/loadsuccess/loadsuccess.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wid:0,
    hei:0,
    sereenwid:0,
    userid:'',
    job1:{},
    club:{}
  },
  partjob:function(){
    var that=this;
    wx.navigateTo({
      url: '/pages/partjob/partjob?userid='+that.data.userid,
    })
  },
  club:function(){
    var that = this;
    wx.navigateTo({
      url: '/pages/club/club?userid=' + that.data.userid,
    })
  },
  getNewjob:function(){
    var that=this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form12.action',
      header: {
        'content-type': 'application/json'
      },
      method:'GET',
      success(res) {
        that.setData({ job1: res.data.job });
        console.log(res);
        var job1 = that.data.job1.job;
        var startdata1 = that.data.job1.startdata;
        var enddata1 = that.data.job1.enddata;
        var name1 = that.data.job1.name;
        var selery1 = that.data.job1.selery;
        var addr1 = that.data.job1.addr;
        var test1 = that.data.job1.test;
        var phone1 = that.data.job1.phone;
        var clubid = that.data.job1.id;
        wx.navigateTo({
          url: '/pages/partjobInfo/partjobInfo?job1=' + job1 + "&name1=" + name1 + "&startdata1=" + startdata1 + "&enddata1=" + enddata1 + "&selery1=" + selery1 + "&addr1=" + addr1 + "&test1=" + test1 + "&phone1=" + phone1 + "&userid=" + that.data.userid + "&clubid=" + clubid,
        })
      }
    })
  },
  getNewclub:function(){
    var that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form15.action',
      header: {
        'content-type': 'application/json'
      },
      method: 'GET',
      success(res) {
        that.setData({ club: res.data.club });
        console.log(res);
        var cname1 = that.data.club.cname;
        var minister1 = that.data.club.minister;
        var enddata1 = that.data.club.enddata;
        var pubtime = that.data.club.pubdata;
        var test1 = that.data.club.test;
        var depart1 = that.data.club.depart;
        var userid1 = that.data.club.userid;
        var date = new Date(that.data.club.pubdata.time);
        var Y = date.getFullYear();
        var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
        var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
        var now = Y + "-" + M + "-" + D + " " + pubtime.hours + ":" + pubtime.minutes + ":" + pubtime.seconds;
        wx.navigateTo({
          url: '/pages/clubdate/clubdate?cname1=' + cname1 + "&minister1=" + minister1 + "&enddata1=" + enddata1 + "&pubdata1=" + now + "&test1=" + test1 + "&depart1=" + depart1 + "&userid1=" + userid1,
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that=this;
    wx.getSystemInfo({
      success: function(res) {
        var widd = parseInt((res.windowWidth - res.windowWidth*0.1 -150) / 2);  
        var heii = parseInt((res.windowHeight-150-65-15-15-10)/2);
        var swid = parseInt((res.windowWidth-15)/2);
        that.setData({ wid: widd});
        that.setData({ hei: heii });
        that.setData({ sereenwid: swid});
        console.log(res.windowWidth);
        console.log(res.windowHeight);
      },
    });
    this.getuser();
  },
  getuser(){
    let that =this;
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo:res.userInfo
        });
        console.log(res.userInfo);
        that.getuserid(res.userInfo);
      }
    })
  },
  getuserid(userInfo){
    let that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form7.action',
      header: {
        'content-type': 'application/json'
      },
      data:{
        data1:userInfo.avatarUrl,
        data2:userInfo.nickName,
      },
      success(res){
        that.setData({ userid:res.data.a});
        console.log(res.data);
      }
    })
  },
  tominiproject:function(){
    wx.navigateTo({
      url: '/pages/out/out',
    })
  },
  talk:function(){
    wx.navigateTo({
      url: '/pages/talk/talk',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})