// pages/publish/publish.js
var timestamp = Date.parse(new Date());
var date = new Date(timestamp);
var Y = date.getFullYear();
var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
var now = Y + "-" + M + "-" + D;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    date: now,
    cname: '',
    minister: '',
    depart: '',
    enddata: '',
    test: '',
    userid:'',
    tip: ''
  },
  onLoad: function (e) {
    this.setData({
      userid: e.userid
    });
    console.log(e.userid);
  },
  bindchagedata: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindsubmit: function (e) {
    if (e.detail.value.cname.length == 0 || e.detail.value.minister.length == 0 || e.detail.value.depart.length == 0 || e.detail.value.test.length == 0 ) {
      this.setData({
        tip: '请完整填写信息'
      });
      return;
    };
    this.setData({ tip: '' });
    wx.request({
      url: 'http://localhost:8082/SHdemo/form9.action',
      data: {
        cname: e.detail.value.cname,
        minister: e.detail.value.minister,
        depart: e.detail.value.depart,
        enddata: e.detail.value.enddata,
        test: e.detail.value.test,
        userid: this.data.userid,
        state: 0,
        isdelete: 0
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        wx.showToast({
          title: '成功',
          icon: 'success',
          duration: 1500,
        });
        setTimeout(function () {
          wx.navigateBack({
            delta: 1
          })
        }, 1000)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})