// pages/partjobInfo/partjobInfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'',
    job:'',
    selery:'',
    startdata:'',
    enddata:'',
    phone:'',
    test:'',
    addr:'',
    userid:'',
    clubid:'',
    photo:'../../images/二维码.jpg',
    scicon:'../../images/收藏.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var job1 = e.job1;
    var startdata1 = e.startdata1;
    var enddata1 =e.enddata1;
    var name1 = e.name1;
    var selery1 = e.selery1;
    var addr1 = e.addr1;
    var test1 = e.test1;
    var phone1 = e.phone1;
    var clubid1=e.clubid;
    this.setData({
      name: name1,
      job: job1,
      selery: selery1,
      startdata: startdata1,
      enddata: enddata1,
      phone: phone1,
      test: test1,
      addr: addr1,
      userid:e.userid,
      clubid: clubid1
    })
  },
  shoucang:function(){
    var that=this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form11.action',
      header: {
        'content-type': 'application/json'
      },
      data:{
        userid:that.data.userid,
        clubid:that.data.clubid
      },
      success:function(res){
        wx.showToast({
          title: '已收藏',
          icon: 'success',
          duration: 1500
        })
      }
    });
  },
  lianxi:function(){
    var that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form8.action',
      data: { userid: that.data.userid },
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        that.setData({
          info: res.data.info
        });
        console.log(res);
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.popup = this.selectComponent("#popup");
    this.info = this.selectComponent("#info");
  },
  showPopup() {
    this.popup.showPopup();
  },

  //取消事件
  _error() {
    console.log('你点击了取消');
    this.popup.hidePopup();
  },
  //确认事件
  _success() {
    console.log('你点击了确定');
    this.popup.hidePopup();
  },

  showInfo() {
    this.info.showInfo();
  },
  success(){
    console.log('你点击了确定');
    this.info.hideInfo();
  },
  call(){
    var that=this;
    wx.makePhoneCall({
        phoneNumber: that.data.phone,}
    );
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})