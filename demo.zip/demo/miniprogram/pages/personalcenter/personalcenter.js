// pages/personalcenter/personalcenter.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userid:'',
    name:'',
    photo:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getuser();
  },
  getuser() {
    let that = this;
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          name: res.userInfo.nickName,
          photo: res.userInfo.avatarUrl
        });
        console.log(res.userInfo);
        that.getuserid(res.userInfo);
      }
    })
  },
  getuserid(userInfo) {
    let that = this;
    wx.request({
      url: 'http://localhost:8082/SHdemo/form7.action',
      header: {
        'content-type': 'application/json'
      },
      data: {
        data1: userInfo.avatarUrl,
        data2: userInfo.nickName,
      },
      success(res) {
        that.setData({ userid: res.data.a});
        console.log(res.data);
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  quit:function(){
    wx.reLaunch({
      url: '/pages/login/login',
    })
  },

  tap1:function(e){
    var that =this;
    wx.navigateTo({
      url: '/pages/myinfo/myinfo?userid=' + that.data.userid,
    })
  },
  tap2: function () {
    var that = this;
    wx.navigateTo({
      url: '/pages/mycollect/mycollect?userid=' + that.data.userid,
    })
  },
  tap3: function () {
    var that = this;
    wx.navigateTo({
      url: '/pages/mypublic/mypublic?userid=' + that.data.userid,
    })
  },
  tap4:function(){
    var that = this;
    wx.navigateTo({
      url: '/pages/clubInfo/clubInfo?userid=' + that.data.userid,
    })
  }
})